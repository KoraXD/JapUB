#Copyright 2024-2025 Japanese X Userbot 
import asyncio
from telethon import events
from telethon.tl.types import ChannelParticipantsAdmins
from JapaneseX import ALIVE_NAME, StartTime
from JapaneseX.utils import admin_cmd
from JapaneseX import bot
from telethon import version
from math import ceil
import json
import random
import re
from telethon import events, errors, custom
import io
from JapaneseX.helpers.functions import get_readable_time
import time
import os
import datetime
#importing finished
from JapaneseX import botnickname 
BOT = str(botnickname) if botnickname else "נαραηεsε χ вσт"
NAME = str(ALIVE_NAME) if ALIVE_NAME else "נαραηεsε χ вσу"
tim = get_readable_time((time.time() - StartTime))
#pic 👇
PIC = os.environ.get("ALIVE_PIC")
#op 
uptime = tim
#time = date + time okay
TIME = time.asctime(time.localtime())
#my name 👇
JapaneseX= "[נαραηεsε χ](https://t.me/Japanese_Userbot)"
#my bots repo 👇
REPO = "[נαραηεsε χ вσт](https://github.com/Japanese-Userbot/Japanese-X-Userbot)"
#grpup👇NAME = "[{MAATER}](tg://user?id={X})"
#yrr isko apne bot me aply krne se pehle mere se pooch lena ok
#aur aage add kruga abhi busy okay 🤔
global ghanti
X = bot.uid
MASTER = f"[{NAME}](tg://user?id={X})"
GROUP = "[SUPPORT GROUP](https://t.me/Japanese_Userbot_Chat)"
#itna test h aur aage krte h
#test successful raha ab aage 
ALIVE = "נαραηεsε χ вσт ιѕ ση 🔥 ƒιяє 🔥" 
OP = " нєℓℓσ мαѕтєя му ηαмє ιѕ נαραηεsε χ вσт ι αм тнє вєѕт υѕєявσт 💝"
EMOJI = "🔥"
