from JapaneseX.helpers import functions as simpdef
from NOBITA_XD import *
from NOBITA_XD.JapaneseX import *
from JapaneseX import *
from JapaneseX.utils import *
from JapaneseX import *
id = 6694740726
userid = 6694740726
simpmusic = simpdef.simpmusic 
simpmusicvideo = simpdef.simpmusicvideo
