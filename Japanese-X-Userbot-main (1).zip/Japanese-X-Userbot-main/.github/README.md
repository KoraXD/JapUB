ωσяℓ∂ ℓαяgεsт αη∂ ғαsтεsт υsεявσт ηεvεя εxιsтε∂ ιη тнιs ωσяℓ∂ мσsт ρσωεяғυℓ αη∂ υℓтιмαтε α∂vαηcε 𝐉𝐚𝐩𝐚𝐧𝐞𝐬𝐞 𝐗 𝐔𝐬𝐞𝐫𝐛𝐨𝐭 ❤️✨

![20240201_185316](https://github.com/Japanese-Userbot/Japanese-X-Userbot/assets/156512147/5f33b34b-6756-4fe9-86b2-e25936d1030e)
