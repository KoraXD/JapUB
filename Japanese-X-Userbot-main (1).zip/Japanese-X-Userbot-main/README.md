# Japanese X Userbot
ωσяℓ∂ ℓαяgεsт αη∂ ғαsтεsт υsεявσт ηεvεя εxιsтε∂ ιη тнιs ωσяℓ∂ мσsт ρσωεяғυℓ αη∂ υℓтιмαтε α∂vαηcε 𝐉𝐚𝐩𝐚𝐧𝐞𝐬𝐞 𝐗 𝐔𝐬𝐞𝐫𝐛𝐨𝐭 ❤️✨
![20240201_185316](https://github.com/Japanese-Userbot/Japanese-X/assets/156512147/21dacdd0-8d46-4114-851f-cd37acbabad8)
